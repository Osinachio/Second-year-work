public class UserInput {
    Integer id, sides;
    Double angle, radius;

    UserInput(Integer id, Integer sides, Double angle, Double radius) {
        this.id = id;
        this.sides = sides;
        this.angle = angle;
        this.radius = radius;
    }
}
