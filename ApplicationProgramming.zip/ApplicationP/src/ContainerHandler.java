import javax.swing.*;
import java.awt.*;

public class ContainerHandler {
    private JTextField idField, sidesField, angleField, radiusField;

    ContainerHandler(JTextField idField, JTextField sidesField, JTextField angleField, JTextField radiusField) {
        this.idField = idField;
        this.sidesField = sidesField;
        this.angleField = angleField;
        this.radiusField = radiusField;
    }

    public UserInput getUserInput() throws NumberFormatException {
        int id = Integer.parseInt(idField.getText());
        int sides = Integer.parseInt(sidesField.getText());
        double angle = Double.parseDouble(angleField.getText());
        double radius = Double.parseDouble(radiusField.getText());
        return new UserInput(id, sides, angle, radius);
    }

    // checks if user input numbers are smaller than or equal to zero. If they are the field will be reset
    public String validateIntegers(int id, int sides, double angle, double radius) {
        String errorMessage = "";
        if(id <= 0) {
            errorMessage += "The ID cannot be smaller than or equal to zero\n";
            idField.setText("000000");
        }
        if(sides <= 0) {
            errorMessage += "The number of sides cannot be smaller than or equal to zero\n";
            sidesField.setText("");
        }
        if(angle <= 0) {
            errorMessage += "The angle cannot be smaller than or equal to zero\n";
            angleField.setText("");
        }
        if(radius <= 0) {
            errorMessage += "The radius cannot be smaller than or equal to zero\n";
            radiusField.setText("");
        }
        return errorMessage;
    }

    public Color getColorFromString(String colorName) {
        return switch (colorName) {
            case "Red" -> Color.RED;
            case "Green" -> Color.GREEN;
            case "Blue" -> Color.BLUE;
            case "Yellow" -> Color.YELLOW;
            default -> Color.BLACK;
        };
    }


}
