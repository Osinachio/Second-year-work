import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class ContainerFrame extends JFrame {
    private ArrayList<RegPolygon> polygons = new ArrayList<>();
    private JPanel drawingPanel;
    private JTextField idField, sidesField, angleField, radiusField;
    private JButton addButton, searchButton, displayButton, sortButton;
    private JComboBox colourDropdown;
    private RegPolygon regPolygon;
    // Helper object for handling user input
    private ContainerHandler handler;

    public ContainerFrame() {
        createComponents();
        layoutComponents();
        addEventHandlers();
        setTitle("Polygon Display");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void createComponents() {
        idField = new JTextField(10);
        idField.setText("000000");
        sidesField = new JTextField(10);
        angleField = new JTextField(10);
        radiusField = new JTextField(10);
        handler = new ContainerHandler(idField, sidesField, angleField, radiusField);

        addButton = new JButton("Add");
        searchButton = new JButton("Search");
        displayButton = new JButton("Display");
        sortButton = new JButton("Sort");

        String[] colors = {"Black", "Red", "Green", "Blue", "Yellow"}; // Add more colors as needed
        colourDropdown = new JComboBox<>(colors);

        drawingPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (regPolygon != null) {
                    regPolygon.drawPolygon((Graphics2D) g, getSize()); // Pass Graphics2D object and size
                }
            }
        };
    }

    private void layoutComponents() {
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Sides:"));
        inputPanel.add(sidesField);
        inputPanel.add(new JLabel("Angle:"));
        inputPanel.add(angleField);
        inputPanel.add(new JLabel("Radius:"));
        inputPanel.add(radiusField);
        inputPanel.add(new JLabel("Color:"));
        inputPanel.add(colourDropdown);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(displayButton);
        buttonPanel.add(sortButton);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(drawingPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void addEventHandlers() {
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPolygon();
            }
        });

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!search()) {
                    showErrorMessage("Polygon with ID '" + idField.getText() + "' does not exist");
                }
            }
        });

        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sort();
            }
        });

        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                display();
            }
        });
    }

    // Find and display polygon with number in ID field.
    // If id cant be found error message is displayed
    private boolean search() {
        String idInput = idField.getText();
        if (idInput != null && !idInput.isEmpty()) {
            int id = Integer.parseInt(idInput);
            RegPolygon foundPolygon = searchPolygonById(id);
            if (foundPolygon != null) {
                drawingPanel.repaint();
                return true;
            }
        }
        return false;
    }

    // Sort ID's in ascending order. Display message in terminal if no ID's are present
    private void sort() {
        if (polygons.isEmpty()) {
            System.out.println("There are no polygon ID's to sort");
            return;
        }
        System.out.println("\nSorted Polygon ID's");
        Collections.sort(polygons);
        for (RegPolygon polygon : polygons) {
            System.out.println(polygon.pId);
        }
        System.out.println();
    }

    // Display list of polygon ID's
    // If there are no polygon ID's, message is displayed in terminal
    private void display() {
        if(polygons.isEmpty()) {
            System.out.println("There are no polygon ID's to display");
            return;
        }
        System.out.println("\nDisplay");
        for(RegPolygon polygon : polygons) {
            System.out.println(polygon.pId);
        }
    }


    // Add polygon to list
    // Show user errors if input is invalid
    private void addPolygon() {
        if (idField.getText().isEmpty()) {
            idField.setText("000000");
        }
        try {
            UserInput userInput = handler.getUserInput();
            Color color = handler.getColorFromString((String) colourDropdown.getSelectedItem());
            String errorMessage = handler.validateIntegers(userInput.id, userInput.sides, userInput.angle, userInput.radius);
            if (!errorMessage.isEmpty()) {
                showErrorMessage(errorMessage);
                return;
            }
            RegPolygon newPolygon = new RegPolygon(userInput.id, color, userInput.sides, userInput.angle, userInput.radius);
            if (isDuplicateID(userInput.id)) {
                showErrorMessage("Polygon with ID '" + userInput.id + "' already exists");
                return;
            }
            polygons.add(newPolygon);
            drawingPanel.repaint();
        } catch (NumberFormatException e) {
            showErrorMessage("Input fields could not be converted to numbers");
        }
    }

    // Finds polygon with ID
    private RegPolygon searchPolygonById(int id) {
        for (RegPolygon poly : polygons) {
            if (poly.getID() == id) {
                regPolygon = poly;
                return poly;
            }
        }
        regPolygon = null;
        return null;
    }

    // Checks if polygon ID already exists
    private Boolean isDuplicateID(Integer id) {
        for (RegPolygon p : polygons) {
            if (p.pId == id) {
                return true;
            }
        }
        return false;
    }

    // Shows error pop-up message
    private void showErrorMessage(String errorMessage) {
        JOptionPane.showMessageDialog(ContainerFrame.this, errorMessage);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ContainerFrame frame = new ContainerFrame();
            frame.setVisible(true);
        });
    }
}










