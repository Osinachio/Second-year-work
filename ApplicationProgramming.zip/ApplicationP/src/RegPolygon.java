import java.awt.*;
import java.util.Arrays;

public class RegPolygon implements Comparable<RegPolygon>{

    Color pColor; // Colour of the polygon, set to a Colour object, default set to black
    int pId = 000000;    // Polygon ID should be a six digit non-negative integer
    int pSides;          // Number of sides of the polygon, should be non-negative value

    double pStarting_angle;   // starting angle

    double pRadius;           // radius of polygon

    int polyCenX;    // x value of centre point (pixel) of polygon when drawn on the panel
    int polyCenY;    // y value of centre point (pixel of polygon when drawn on the panel
    double [] pointsX;  // int array containing x values of each vertex (corner point) of the polygon
    double [] pointsY;  // int array containing y values of each vertex (corner point) of the polygon

    public RegPolygon(int pSides, double stAngle, double rad, int pId) {

        this.pSides = Math.max(pSides, 3);              // user defined number of sides should be non-negative
        this.pStarting_angle = stAngle;   // user defined starting angle
        this.pRadius = Math.max(rad, 0);                // user defined radius
        this.pId = pId;
        this.pColor=Color.black;
        initializePoints();

    }

    private void initializePoints() {
        pointsX = new double[this.pSides];
        pointsY = new double[this.pSides];
        double angleIncrement = 2 * Math.PI / this.pSides;
        for (int i = 0; i < this.pSides; i++) {
            double currentAngle = this.pStarting_angle + angleIncrement * i;
            pointsX[i] = this.pRadius * Math.cos(currentAngle);
            pointsY[i] = this.pRadius * Math.sin(currentAngle);
        }
    }


    public RegPolygon(int id, Color color, int sides, double angle, double radius) {
        this.pId = id;
        this.pColor = color;
        this.pSides = Math.max(sides, 3); // Ensure at least 3 sides
        this.pStarting_angle = angle;
        this.pRadius = Math.max(radius, 0); // Ensure non-negative radius
        initializePoints();
    }

    private Polygon getPolygonPoints(Dimension dim) {

        polyCenX = dim.width / 2;                  // x value of centre point of the polygon
        polyCenY = dim.height / 2;                 // y value of centre point of the polygon
        double angleIncrement = 2 * Math.PI / pSides;  // incremenet of each angle
        Polygon p = new Polygon();
        for (int i = 0; i < pSides; i++){
            double angle = pStarting_angle + angleIncrement * i;

            int x =(int) (polyCenX + pRadius * Math.cos(angle));
            int y =(int) (polyCenY + pRadius * Math.sin(angle));

            pointsX[i] = x;
            pointsY[i] = y;

            p.addPoint(x,y);
        }
        pStarting_angle += angleIncrement;
        return p;


    }


    public void drawPolygon(Graphics2D g, Dimension d) {
        g.setColor(pColor);

        g.drawPolygon(getPolygonPoints(d));
    }


    // gets a stored ID
    public int getID() {
        return pId;
    }


    @Override
    // method used for comparing PolygonContainer objects based on stored ids, you need to complete the method
    public int compareTo(RegPolygon o) {

        return Integer.compare(this.pId, o.pId);
    }


    // outputs a string representation of the PolygonContainer object, you need to complete this to use for testing
    public String toString(){
        return "RegPolygon{" +
                "pId=" + pId +
                ", pColor=" + pColor +
                ", pSides=" + pSides +
                ", pStarting_angle=" + pStarting_angle +
                ", pRadius=" + pRadius +
                ", polyCenX=" + polyCenX +
                ", polyCenY=" + polyCenY +
                ", pointsX=" + Arrays.toString(pointsX) +
                ", pointsY=" + Arrays.toString(pointsY) +
                '}';
    }
}
