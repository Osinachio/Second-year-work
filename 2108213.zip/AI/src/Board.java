//You are supposed to add your comments

import java.util.*;

class Point {
    //represents a point on the board with x and y coordinates
    int x, y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "[" + (x+1) + ", " + (y+1) + "]";
    }
}
//associates a score with a specific point
class PointsAndScores {
    int score;
    Point point;

    PointsAndScores(int score, Point point) {
        this.score = score;//score evaluated for this move
        this.point = point;// specific point on the board this score is associated with
    }
}
//shows the game board and its state
class Board {
    List<Point> availablePoints;//stores points on the board that are not yet occupied
    Scanner scan = new Scanner(System.in);// reads user input
    int[][] board = new int[5][5];// adjusted to a 5x5 grid

    public Board() {
    }
    //checks if a line (row, column, or diagonal) contains 5 of the same player's mark
    private boolean checkLine(int player, int startX, int startY, int dx, int dy) {
        int count = 0;
        for (int i = 0; i < 5; i++) { // Iterates over 5 points in a specified direction (dx, dy)
            if (startX + i * dx >= 0 && startX + i * dx < 5 && startY + i * dy >= 0 && startY + i * dy < 5) { // Ensure the indices are within bounds
                if (board[startX + i * dx][startY + i * dy] == player) {
                    count++;
                    if (count == 5) return true; // 5 in a row found
                } else {
                    count = 0; // Reset count if a sequence is broken
                }
            }
        }
        return false; // No 5 in a row found
    }

// determines if the game is over either by a win condition or if the board is full
    public boolean isGameOver() {
        return (hasXWon() || hasOWon() || getAvailablePoints().isEmpty());
    }
// checks if player X has won
    public boolean hasXWon() {// checks all rows, columns and diagonals are a win condition
        for (int i = 0; i < 5; i++) {
            if (checkLine(1, i, 0, 0, 1) || checkLine(1, 0, i, 1, 0)) {
                return true;
            }
        }
        return checkLine(1, 0, 0, 1, 1) || checkLine(1, 0, 4, 1, -1);

    }
// checks if player O has won
    public boolean hasOWon() {
        for (int i = 0; i < 5; i++) { // checks all rows and columns and diagonals for a win condition
            if (checkLine(2, i, 0, 0, 1) || checkLine(2, 0, i, 1, 0)) {
                return true;
            }
        }
        return checkLine(2, 0, 0, 1, 1) || checkLine(2, 0, 4, 1, -1);

    }
// returns list of points that are not yet occupied on the board
    public List<Point> getAvailablePoints() {
        availablePoints = new ArrayList<>();
        for (int i = 0; i < 5; ++i) {
            for (int j = 0; j < 5; ++j) {
                if (board[i][j] == 0) {
                    availablePoints.add(new Point(i, j));
                }
            }
        }
        return availablePoints;
    }
//returns the state of a specific point on the board
    public int getState(Point point) {
        return board[point.x][point.y];
    }
// places a move on the board for a given player at the specified point
    public void placeAMove(Point point, int player) {
        board[point.x][point.y] = player;
    }
// displayes current state of the board
    public void displayBoard() {
        System.out.println();

        for (int i = 0; i < 5; ++i) {
            for (int j = 0; j < 5; ++j) {
                System.out.print(board[i][j] == 0 ? ". " : (board[i][j] == 1 ? "X " : "O "));
            }
            System.out.println();
        }
    }
}
