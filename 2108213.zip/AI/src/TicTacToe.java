//You are supposed to add your comments

import java.util.*;

public class TicTacToe {

    public static void main(String[] args) {
        AIplayer AI= new AIplayer();// initialize AI player and the game board
        Board b = new Board();
        Point bestMove;//variable to store AI's best move

        b.displayBoard();// displays empty game board

        System.out.println("Who makes first move? (1)Computer (2)User: ");//prompts user to decide who makes the first move
        int choice = b.scan.nextInt();
        if(choice == 1){// if the computer is chosen to make the first move
            AI.callMinimax(0, 1, b);// calling the minimax algorithm for the AI to decide its move
            bestMove = AI.returnBestMove();//
            if (isValidMove(bestMove)){//check if the move is valid
                b.placeAMove(bestMove,1);
                b.displayBoard();// display the updated board
            }else {
                System.out.println("No valid moves for AI");// in case no valid moves are found
            }
        }
//validating user's move; repeat until a valid move is made
        while (!b.isGameOver()) {
            System.out.println("Your move: line (1 to 5) colunm (1 to 5)");
            Point userMove = new Point(b.scan.nextInt()-1, b.scan.nextInt()-1);
            while (b.getState(userMove)!=0 || userMove.x < 0 || userMove.x >= 5 || userMove.y < 0 || userMove.y >= 5) {
                System.out.println("Invalid move. Make your move again: ");
                userMove.x=b.scan.nextInt()-1;
                userMove.y=b.scan.nextInt()-1;
            }
            b.placeAMove(userMove, 2);// place the user's move on the board
            b.displayBoard();

            if (b.isGameOver()) {// check if the game is over
                break;
            }

            AI.callMinimax(0, 1, b);// AI is evaluating its move using the minimax algorithm
            bestMove = AI.returnBestMove();// it selects its best move
            if (isValidMove(bestMove)){
                b.placeAMove(bestMove, 1);// place ai's move on the board
                b.displayBoard();// display the updated board
            }else {
                System.out.println("No valid moves available for AI");// in case no valid moves are found
                break;
            }
        }
        // announces game outcome
        if (b.hasXWon()) {
            System.out.println("Unfortunately, you lost!");
        } else if (b.hasOWon()) {
            System.out.println("You win!");
        } else {
            System.out.println("It's a draw!");
        }
    }
    //method to check if a given move is within the bounds of the board
    private static boolean isValidMove(Point move) {
        return move.x >= 0 && move.x < 5 && move.y >= 0 && move.y < 5;
    }
}
