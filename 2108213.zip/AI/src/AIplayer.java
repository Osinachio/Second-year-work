//You are supposed to add your comments

import java.util.*;

class AIplayer {
    List<Point> availablePoints;
    List<PointsAndScores> rootsChildrenScores;
    Board b = new Board();

    public AIplayer() {
    }

    public Point returnBestMove() {
        int MAX = -100000;
        int best = -1;

        for (int i = 0; i < rootsChildrenScores.size(); ++i) {
            if (MAX < rootsChildrenScores.get(i).score) {// returns the best move in a list of points based on the score
                MAX = rootsChildrenScores.get(i).score;
                best = i;
            }
        }
        return rootsChildrenScores.get(best).point;
    }

    public int returnMin(List<Integer> list) {
        int min = Integer.MAX_VALUE;
        int index = -1;

        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i) < min) {// returns minimum value in list
                min = list.get(i);
                index = i;
            }
        }
        return list.get(index);
    }

    public int returnMax(List<Integer> list) {
        int max = Integer.MIN_VALUE;
        int index = -1;

        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i) > max) { //returns max value in the list
                max = list.get(i);
                index = i;
            }
        }
        return list.get(index);
    }

    public void callMinimax(int depth, int turn, Board b){
        rootsChildrenScores = new ArrayList<>();
        minimax(depth, turn, b, -100000, 100000);
    }

    public int minimax(int depth, int turn, Board b, int alpha, int beta) {
       int currentHeuristic = currentHeuristic(b);
       if (depth == 7){
           return currentHeuristic;// limits the depth to prevent time consumption
       }
       List <Point> pointsAvailable = b.getAvailablePoints();
       if (pointsAvailable.isEmpty()) return currentHeuristic; //returns currentHeuristic if no moves are available

       int score = (turn == 1) ? Integer.MIN_VALUE : Integer.MAX_VALUE;// initialise score based on player

       for (Point point : pointsAvailable){
           b.placeAMove(point, turn);// simulate the move
           int currentScore = minimax(depth + 1, turn == 1 ? 2 : 1, b, alpha, beta);// calling minimax for the next depth, alternating turns
           if (turn == 1){
               score = Math.max(score, currentScore);// updating score and alpha if we have a better score
               alpha = Math.max(alpha, score);
               if (depth == 0)rootsChildrenScores.add(new PointsAndScores(currentScore,point));
           }else {
               score = Math.min(score, currentScore);// updating score and beta for minimizing player
               beta = Math.min(beta, score);
           }
           b.placeAMove(point, 0);// alpha beta pruning: cut off the search if necessary

           if (beta <= alpha) break;
       }
       return score; //returns best score

    }
    public int currentHeuristic(Board b) {
        int heuristicValue = 0;
        final int[] powers = {0, 10, 100, 1000, 10000, 100000};

        // Evaluate diagonals first
        int[] diagonalCounts = evaluateDiagonals(b);
        heuristicValue += powers[diagonalCounts[0]] - powers[diagonalCounts[1]];
        heuristicValue += powers[diagonalCounts[2]] - powers[diagonalCounts[3]];

        // Evaluate all rows and columns
        for (int i = 0; i < 5; i++) {
            int[] lineCounts = evaluateLine(b, i);
            heuristicValue += powers[lineCounts[0]] - powers[lineCounts[1]]; // horizontal line for player 1 and player 2
            heuristicValue += powers[lineCounts[2]] - powers[lineCounts[3]]; // vertical line for player 1 and player 2
        }

        return heuristicValue;
    }

    private int[] evaluateDiagonals(Board b) {
        int[] counts = {0, 0, 0, 0};
        for (int i = 0; i < 5; i++) {
            // Left diagonal
            counts[0] += b.board[i][i] == 1 ? 1 : 0;
            counts[1] += b.board[i][i] == 2 ? 1 : 0;
            // Right diagonal
            counts[2] += b.board[i][4 - i] == 1 ? 1 : 0;
            counts[3] += b.board[i][4 - i] == 2 ? 1 : 0;
        }
        return counts;
    }

    private int[] evaluateLine(Board b, int index) {
        int[] counts = {0, 0, 0, 0};
        for (int j = 0; j < 5; j++) {
            // Horizontal line
            counts[0] += b.board[index][j] == 1 ? 1 : 0;
            counts[1] += b.board[index][j] == 2 ? 1 : 0;
            // Vertical line
            counts[2] += b.board[j][index] == 1 ? 1 : 0;
            counts[3] += b.board[j][index] == 2 ? 1 : 0;
        }
        return counts;
    }

}


